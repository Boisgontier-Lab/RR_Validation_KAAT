##########################################
### Manikin task: Behavioral outcomes ####
##########################################
rm(list=ls())

# insert the csv in the script
#dataMT_EEG <- read.csv("C:/Users/cheval/switchdrive/Boris/Recherche/Recherche en cours/MT EEG/Zenodo/data management/raw_data_eprime_zen.csv",sep=";")
dataMT_EEG <- read.csv("/Users/cheval/switchdrive/Boris/Recherche/Recherche en cours/MT EEG/Zenodo/data management/raw_data_eprime_zen.csv",sep=";")

##########
#### To build the factor type of "stimuli" (physical activity versus sedentary behaviors versus neutral)
#########
# indicate images as factor
dataMT_EEG$image <- factor(dataMT_EEG$image)

# regroup images by category of stimuli with neutral square and circle separately
dataMT_EEG$Stimuli <- NA
dataMT_EEG$Stimuli[is.element(dataMT_EEG$image,c("AP-COUR.jpg", "AP-FOOT.jpg", "AP-NAT.jpg",
                                                              "AP-RANDO.jpg", "AP-VEL.jpg"))] <- "PA"

dataMT_EEG$Stimuli[is.element(dataMT_EEG$image,c("SED-CANAP.jpg", "SED-HAMAC.jpg", "SED-JVID.jpg",
                                                              "SED-LECT.jpg", "SED-TV.jpg"))] <- "SB"

dataMT_EEG$Stimuli[is.element(dataMT_EEG$image,c("AP-COURr.jpg", "AP-FOOTr.jpg", "AP-NATr.jpg",
                                                              "AP-RANDOr.jpg", "AP-VELr.jpg", "SED-CANAPr.jpg",
                                                              "SED-HAMACr.jpg", "SED-JVIDr.jpg", "SED-LECTr.jpg",
                                                              "SED-TVr.jpg"))] <- "stimuli_rond"

dataMT_EEG$Stimuli[is.element(dataMT_EEG$image,c("AP-COURc.jpg", "AP-FOOTc.jpg", "AP-NATc.jpg",
                                                              "AP-RANDOc.jpg", "AP-VELc.jpg", "SED-CANAPc.jpg",
                                                              "SED-HAMACc.jpg", "SED-JVIDc.jpg", "SED-LECTc.jpg",
                                                              "SED-TVc.jpg"))] <- "stimuli_carre"

# indicate codestimuli as factor
dataMT_EEG$Stimuli <- factor(dataMT_EEG$Stimuli)

##########
#### build the factor "Action"  (approach versus avoidance)
#########
dataMT_EEG$groups <- interaction(factor(dataMT_EEG$Stimuli), factor(dataMT_EEG$Procedure.Trial.))
dataMT_EEG$groups2 <-  revalue(dataMT_EEG$groups, 
                                  c("PA.compat1"="PA compatall",
                                    "PA.compat2"="PA compatall",
                                    "SB.compat1"="SB compatall",
                                    "SB.compat2"="SB compatall",
                                    "stimuli_carre.compat1" = "stimuli_carre.compatall",
                                    "stimuli_carre.compat2" = "stimuli_carre.compatall",
                                    "stimuli_rond.compat1" = "stimuli_rond.compatall",
                                    "stimuli_rond.compat2" = "stimuli_rond.compatall"))

dataMT_EEG$Action <-  revalue(dataMT_EEG$groups, 
                                        c("PA.compat1"="Approach",
                                          "PA.compat2"="Approach",
                                          "SB.compat1"="Avoid",
                                          "SB.compat2"="Avoid",
                                          "stimuli_carre.compat1" = "Avoid",
                                          "stimuli_carre.compat2" = "Avoid",
                                          "stimuli_rond.compat1" = "Approach",
                                          "stimuli_rond.compat2" = "Approach",   
                                          "PA.incomp1"="Avoid",
                                          "PA.incomp2"="Avoid",
                                          "SB.incomp1"="Approach",
                                          "SB.incomp2"="Approach",
                                          "stimuli_carre.incomp1" = "Approach",
                                          "stimuli_carre.incomp2" = "Approach",
                                          "stimuli_rond.incomp1" = "Avoid",
                                          "stimuli_rond.incomp2" = "Avoid"))


### indicate subject as a factor (29 levels)
dataMT_EEG$Subject <-  factor(dataMT_EEG$Subject)

### create a dataset with only meaninful variables
data_main <- data.frame (subject =dataMT_EEG$Subject, Stimuli=dataMT_EEG$Stimuli,
                         Action = dataMT_EEG$Action, RT = dataMT_EEG$Slide4.RT, 
                         images=dataMT_EEG$image, Accuracy = dataMT_EEG$Slide4.ACC, 
                         Training =dataMT_EEG$Procedure.SubTrial.)
  
#############
### Data cleaning  
#############
## select reaction times from 200 to 1500 ms
limit_RT <- c(200,1500)
## indicate RT as numeric 
data_main$RT <- as.numeric(as.character(data_main$RT))
## selected RT as numeric 
data_main$selected <- data_main$RT > limit_RT [1] & data_main$RT < limit_RT [2]

### keep only RT between 200 and 1500 ms, and accurate (i.e., correct response) and not fro the training procedure
data_main <- data_main[data_main$Training=="TrailProc",]
data_main <- data_main[data_main$selected,]
data_main <- data_main[data_main$Accuracy==1,]

## keep only useful variables
keepVars <- c("subject", "Stimuli","Action", "RT", "images")
data_main <- data_main [, keepVars]



### insert the self-reported data
#data_SR <- read.csv("C:/Users/cheval/switchdrive/Boris/Recherche/Recherche en cours/MT EEG/Zenodo/data management/data_self_report_R_subset_zen.csv",sep=";")
data_SR <- read.csv("/Users/cheval/switchdrive/Boris/Recherche/Recherche en cours/MT EEG/Zenodo/data management/data_self_report_R_subset_zen.csv",sep=";")

# Merge behavioral (manikin task) and self-reported data
data_main_all <- merge(data_SR, data_main, by="subject", all.x =TRUE)

## save all the behavioral and self reported data
#setwd("C:/Users/cheval/switchdrive/Boris/Recherche/Recherche en cours/MT EEG/Zenodo/data management")
setwd("/Users/cheval/switchdrive/Boris/Recherche/Recherche en cours/MT EEG/Zenodo/data management")

# as R Data
save(data_main_all,  file =  "data_behavioral.RData")

# as csv
write.csv2(data_main_all, row.names = TRUE , file="data_behavioral.csv")

